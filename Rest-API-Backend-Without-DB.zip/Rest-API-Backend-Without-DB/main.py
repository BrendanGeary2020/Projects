from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pymongo import MongoClient
from dotenv import load_dotenv
import os


# Load environment variables from .env
load_dotenv()


# MongoDB configuration
MONGODB_URI = os.getenv("MONGODB_URI")
MONGODB_DATABASE = os.getenv("MONGODB_DATABASE")


# Connect to MongoDB
client = MongoClient(MONGODB_URI)

db = client[MONGODB_DATABASE]

employees_collection = db["employees"]


# Test MongoDB connection
try:
    client.admin.command("ping")
    print("MongoDB connection successful!")
except Exception as e:
    print("MongoDB connection failed:", e)


# Create FastAPI application
app = FastAPI()


# Employee model
class Employee(BaseModel):
    id: int
    name: str
    department: str
    salary: float


# Chapter 1 in-memory data
employees = [
    Employee(
        id=1,
        name="John Smith",
        department="IT",
        salary=65000
    ),
    Employee(
        id=2,
        name="Sarah Jones",
        department="HR",
        salary=60000
    )
]

# Add initial employees to MongoDB
for employee in employees:

    existing_employee = employees_collection.find_one({
        "id": employee.id
    })

    if not existing_employee:
        employees_collection.insert_one(
            employee.model_dump()
        )


# GET - Get all employees
@app.get("/employees")
def get_employees():
    return employees


# GET - Get one employee
@app.get("/employees/{employee_id}")
def get_employee(employee_id: int):

    for employee in employees:

        if employee.id == employee_id:
            return employee

    raise HTTPException(
        status_code=404,
        detail="Employee not found"
    )


# POST - Create employee
@app.post("/employees")
def create_employee(employee: Employee):

    employees.append(employee)

    return employee


# PUT - Update employee
@app.put("/employees/{employee_id}")
def update_employee(
    employee_id: int,
    updated_employee: Employee
):

    for index, employee in enumerate(employees):

        if employee.id == employee_id:

            employees[index] = updated_employee

            return updated_employee

    raise HTTPException(
        status_code=404,
        detail="Employee not found"
    )


# DELETE - Delete employee
@app.delete("/employees/{employee_id}")
def delete_employee(employee_id: int):

    for index, employee in enumerate(employees):

        if employee.id == employee_id:

            deleted_employee = employees.pop(index)

            return deleted_employee

    raise HTTPException(
        status_code=404,
        detail="Employee not found"
    )